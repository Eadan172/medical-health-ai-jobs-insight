# GitHub 发布指南

## 📦 项目打包

项目已完成所有修改，文件位于 `/mnt/okcomputer/output/app/` 目录下。

## 🚀 发布到 GitHub 步骤

### 1. 创建 GitHub 仓库

1. 登录 [GitHub](https://github.com)
2. 点击右上角 **+** 按钮，选择 **New repository**
3. 填写仓库信息：
   - **Repository name**: `medical-health-ai-jobs-insight`
   - **Description**: 医药健康+AI岗位洞察平台 - 实时聚合51job、Boss直聘、猎聘网数据
   - **Visibility**: Public (推荐)
   - 勾选 **Add a README file**
4. 点击 **Create repository**

### 2. 上传项目文件

#### 方式一：通过 Git 命令行

```bash
# 克隆空仓库
git clone https://github.com/YOUR_USERNAME/medical-health-ai-jobs-insight.git
cd medical-health-ai-jobs-insight

# 复制项目文件到该目录
# ... 复制所有文件 ...

# 添加文件到仓库
git add .

# 提交更改
git commit -m "Initial commit: Medical Health + AI Jobs Insight Platform

Features:
- Job data visualization from 51job, Boss, Liepin
- Smart filtering and sorting
- Daily auto-update
- Headhunter resources section
- Company scale analysis"

# 推送到 GitHub
git push origin main
```

#### 方式二：通过 GitHub Web 界面

1. 在仓库页面点击 **Add file** → **Upload files**
2. 拖拽或选择项目文件上传
3. 填写提交信息
4. 点击 **Commit changes**

### 3. 启用 GitHub Pages

1. 进入仓库 **Settings** 标签
2. 左侧菜单选择 **Pages**
3. **Source** 选择 **Deploy from a branch**
4. **Branch** 选择 **main** 分支，文件夹选择 **/(root)**
5. 点击 **Save**
6. 等待几分钟后，访问 `https://YOUR_USERNAME.github.io/medical-health-ai-jobs-insight`

### 4. 项目文件清单

需要上传的文件：

```
medical-health-ai-jobs-insight/
├── public/
│   └── data/
│       ├── agencies.json          # 猎头机构数据
│       ├── headhunters.json       # 猎头数据
│       ├── jobs.json              # 岗位数据
│       └── stats.json             # 统计数据
├── src/
│   ├── App.tsx                    # 主应用组件
│   ├── App.css                    # 全局样式
│   ├── index.css                  # 入口样式
│   └── main.tsx                   # 入口文件
├── index.html
├── package.json
├── package-lock.json
├── tsconfig.json
├── tsconfig.app.json
├── tsconfig.node.json
├── tailwind.config.js
├── postcss.config.js
├── vite.config.ts
├── components.json
├── eslint.config.js
├── README.md                      # 项目说明
└── .gitignore                     # Git忽略文件
```

### 5. 项目截图

建议添加以下截图到 README：

1. 首页 Hero 区域
2. 平台生态概览
3. 薪资分布图表
4. 岗位列表与筛选
5. 猎头资源区域

## 📋 修改记录

### v1.1.0 更新内容

1. **文案修改**
   - 将"公司实力"改为"公司体量"

2. **新增猎头资源板块**
   - 专业猎头顾问卡片（6位）
   - 知名猎头机构展示（4家）
   - 点击头像/机构可跳转对应页面

3. **增强饼图交互**
   - 悬停显示薪资区间详情
   - 展示热门城市和热门岗位

4. **每日更新按钮**
   - 点击刷新当天0点后数据
   - 显示更新结果提示

## 🔗 相关链接

- **在线演示**: https://fpbec7iecuz4g.ok.kimi.link
- **技术栈**: React + TypeScript + Vite + Tailwind CSS + Recharts

## 💡 提示

如需帮助，请参考：
- [GitHub Docs - Creating a new repository](https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository)
- [GitHub Docs - GitHub Pages](https://docs.github.com/en/pages)
